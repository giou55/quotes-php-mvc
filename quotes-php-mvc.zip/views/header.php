<div class="row align-items-center justify-content-center mb-4 text-light bg-dark">

    <div class="col-12 col-sm-4 col-md-4 col-lg-2 col-xl-3 p-3">
          <a class="text-light mr-3" href="/quotes">Αρχική</a>
          <a class="text-light mr-3" href="/authors">Πρόσωπα</a>
          <a class="text-light mr-3" href="/tags">Tags</a>
    </div>

    <div class="col-12 col-sm-8 col-md-8 col-lg-4 col-xl-5 p-3">
      <h3>Ευφυολογήματα, Σοφά Λόγια, Αποφθέγματα</h3>
    </div>

    <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-4 p-3">
      <form class="form-inline" method="post" action="/quotes/search">
        <input type="text" name="search" style="min-width:260px" class="form-control mr-sm-2" placeholder="Αναζήτηση στα αποφθέγματα..." value="">
        <button class="btn btn-success" type="submit">Αναζήτηση</button>
      </form>
    </div>

</div>



  


