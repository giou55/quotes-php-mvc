<div class="d-flex flex-row justify-content-between align-items-center mb-4 text-light bg-dark p-2">
    <div>
        <a class="text-light ml-3" href="/quotes">Αρχική</a>
        <a class="text-light ml-3" href="/authors">Πρόσωπα</a>
        <a class="text-light ml-3" href="/tags">Tags</a>
    </div>

      <h2>Ευφυολογήματα, Σοφά Λόγια, Αποφθέγματα</h2>

      <form class="form-inline" action="/quotes">
        <input type="text" name="search" style="min-width:300px" class="form-control mr-sm-2" placeholder="Αναζήτηση στα αποφθέγματα..." value="<?php echo $search ?>">
        <button class="btn btn-success" type="submit">Search</button>
      </form>
</div>
  


